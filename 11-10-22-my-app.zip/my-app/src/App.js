import image from './logo.svg';
import './App.css';
import Button from './Button/Button';
import Userbox from './Userbox/Userbox';

function App(props) {

  let a = 5;
  let b = 10;

  console.log(props);

  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={image} className="App-logo" alt="logo" /> */}
        {/* <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a> */}
{/* 
        <p>{a*b}</p>
        <h4>{props.name}</h4>
        <h4>{props.age}</h4>
        <Button name="Click"></Button>
        <Button name="Submit"/> */}

        <Userbox img="1.jpg" name="Vivek"/>
        <Userbox img="2.jpg" name="Utkarsh"/>
        <Userbox img="3.jpg" name="Saqlain"/>

      </header>
    </div>
  );
}

export default App;
