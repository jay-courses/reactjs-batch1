import classes from './ProductsSummary.module.css';

const ProductsSummary = () => {
  return (
    <section className={classes.summary}>
      <h2>Ecommerce Online Store</h2>
      <p>
        Online Ecommerce Store app built using react.
      </p>
    </section>
  );
};

export default ProductsSummary;
