import Userbox from './Userbox/Userbox';
import {users} from './data.js';
  
  function UsersList() {

    // const users = [
    //   {img: "1.jpg", name: 'Vivek'},
    //   {img: "2.jpg", name: 'Utkarsh'},
    //   {img: "3.jpg", name: 'Saqlain'},
    // ];    

    return (
      <>
          {users.map((user) => <Userbox img={user.img} name={user.name}/>  )}
      </>
    );
  }

  export default UsersList;