import { useState, createContext, useContext } from "react";
import ReactDOM from "react-dom/client";

const ModeContext = createContext();

function Component1() {
    const [mode, setMode] = useState("light");

    return (
        <ModeContext.Provider value={mode}>
            <div className={"App " + mode + ""}>
                <h1>{`Mode is ${mode}!`}</h1>
                <input type="button" value="Light mode" onClick={() => setMode("light")} />
                <input type="button" value="Dark mode" onClick={() => setMode("dark")} />
                <Component2 />
            </div>
        </ModeContext.Provider>
    );
}

function Component2() {
    return (
        <>
            <h1>Component 2</h1>
            <Component3 />
        </>
    );
}

function Component3() {
    return (
        <>
            <h1>Component 3</h1>
            <Component4 />
        </>
    );
}

function Component4() {
    return (
        <>
            <h1>Component 4</h1>
            <Component5 />
        </>
    );
}

function Component5() {
    const mode = useContext(ModeContext);

    return (
        <>
            <h1>Component 5</h1>
            <h2>{`Mode is ${mode} `}</h2>
        </>
    );
}


export { Component1 };

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<Component1 />);