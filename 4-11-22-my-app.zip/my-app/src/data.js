const users = [
    {img: "1.jpg", name: 'Vivek'},
    {img: "2.jpg", name: 'Utkarsh'},
    {img: "3.jpg", name: 'Saqlain'},
  ];

  const a = 10;

//   export default users;

const car1 = {
  brand: "Ford",
  model: "Mustang",
  year: "1964",
  color: "red"
};
const car2 = {
  brand: "Maruti",
  model: "Baleno",
  year: "1998",
  color: "blue"
};
const car3 = {
  brand: "Tata",
  model: "Safari",
  year: "1974",
  color: "black"
};


const carsObj = [
  car1, car2, car3
];

const fruit = {
  name: "mango",
  season: "summer"
}


    export {users , a , car1, car2, car3, carsObj, fruit};