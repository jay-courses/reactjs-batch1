import './Button.css';

function Button(props){
    return <input type="button" value={props.name} className='btn'/>
}

export default Button;