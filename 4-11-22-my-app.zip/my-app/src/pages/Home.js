const Home = (props) => {
    return <h1 className={props.myclass}>Home</h1>;
  };
  
  export default Home;