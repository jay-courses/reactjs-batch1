const Signin = () => {
    return <h1>Signin</h1>;
  };
  
  export default Signin;