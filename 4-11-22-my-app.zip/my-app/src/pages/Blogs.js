const Blogs = (props) => {
    return <h1 className={props.myclass}>Blog Articles</h1>;
  };
  
  export default Blogs;