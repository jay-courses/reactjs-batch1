import React, { useRef } from 'react';

import classes from './AddBlog.module.css';

function AddBlog(props) {
  const titleRef = useRef('');
  const bodyRef = useRef('');

  function submitHandler(event) {
    event.preventDefault();

    // could add validation here...

    const blog = {
      title: titleRef.current.value,
      body: bodyRef.current.value,
    };

    props.onAddBlog(blog);
  }

  return (
    <form onSubmit={submitHandler}>
      <div className={classes.control}>
        <label htmlFor='title'>Title</label>
        <input type='text' id='title' ref={titleRef} />
      </div>
      <div className={classes.control}>
        <label htmlFor='opening-text'>Body</label>
        <textarea rows='5' id='opening-text' ref={bodyRef}></textarea>
      </div>
      <button>Add Blog</button>
    </form>
  );
}

export default AddBlog;
