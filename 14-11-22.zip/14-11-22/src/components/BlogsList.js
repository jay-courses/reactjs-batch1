import React from 'react';

import Blog from './Blog';
import classes from './BlogsList.module.css';

const BlogList = (props) => {
  return (
    <ul className={classes['blogs-list']}>
      {props.blogs.map((blog) => (
        <Blog
          key={blog.id}
          title={blog.title}
          body={blog.body}
        />
      ))}
    </ul>
  );
};

export default BlogList;
