import React from 'react';

import classes from './Blog.module.css';

const Blog = (props) => {
  return (
    <li className={classes.blog}>
      <h2>{props.title}</h2>
      <p>{props.body}</p>
    </li>
  );
};

export default Blog;
