import React, { useState, useEffect, useCallback } from 'react';

import BlogsList from './components/BlogsList';
import AddBlog from './components/AddBlog';
import './App.css';

function App() {
  const [blogs, setBlogs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchBlogsHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('https://jsonplaceholder.typicode.com/posts/');
      if (!response.ok) {
        throw new Error('Something went wrong!');
      }

      const data = await response.json();

      const transformedBlogs = data.map((blogData) => {
        return {
          id: blogData.id,
          title: blogData.title,
          body: blogData.body,
        };
      });
      setBlogs(transformedBlogs);
    } catch (error) {
      setError(error.message);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchBlogsHandler();
  }, [fetchBlogsHandler]);

  function addBlogHandler(blog) {
    console.log(blog);
  }

  let content = <p>Found no blogs.</p>;

  if (blogs.length > 0) {
    content = <BlogsList blogs={blogs} />;
  }

  if (error) {
    content = <p>{error}</p>;
  }

  if (isLoading) {
    content = <p>Loading...</p>;
  }

  return (
    <React.Fragment>
      <section>
        <AddBlog onAddBlog={addBlogHandler} />
      </section>
      <section>
        <button onClick={fetchBlogsHandler}>Fetch Blogs</button>
      </section>
      <section>{content}</section>
    </React.Fragment>
  );
}

export default App;
