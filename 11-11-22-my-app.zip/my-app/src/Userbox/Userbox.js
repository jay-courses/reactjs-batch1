import Image from '../Image/Image';
import Name from '../Name/Name';
import './Userbox.css';

function Userbox(props){

    return <div className="userbox">
        <Image filename={"assets/img/" + props.img}/>
        <Name name={props.name}/>
    </div>;
}

export default Userbox;