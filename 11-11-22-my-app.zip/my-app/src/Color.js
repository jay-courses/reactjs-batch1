import {useState} from 'react';

function Color(props){

    const [name, setName] = useState("");

    const sendData = () => {
        props.onAddColor(name);
    };

    return <div>
        Color Name: <input value={name} onChange={(e) => setName(e.target.value)} />
        <input type="button" onClick={sendData} value="Send Data"/>

    </div>;

}

export default Color;