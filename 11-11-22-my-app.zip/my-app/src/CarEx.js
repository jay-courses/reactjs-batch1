import { useState } from "react";

function CarEx(props) {
    const [car, setCar] = useState(props.data);
    
    const updateColor = () => {
      setCar(previousState => {
        return { ...previousState, color: "blue" }
      });
    }
  
    return (
      <>
        <h3>My {car.brand}</h3>
        <p>
          It is a {car.color} {car.model} from {car.year}.
        </p>
        <button
          type="button"
          onClick={updateColor}
        >Blue</button>
        <hr/>
      </>
    )
  }
  export default CarEx;