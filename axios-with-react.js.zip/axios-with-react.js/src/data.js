// const cars = ['Ford', 'BMW', 'Audi'];

const cars = [
  {
    id: 1,
    brand: "Maruti",
    model: "Ertiga",
    year: "1970",
    color: "white"
  },
  {
    id: 2,
    brand: "Ford",
    model: "Mustang",
    year: "1964",
    color: "red"
  },
  {
    id: 3,
    brand: "Tata",
    model: "Safari",
    year: "1989",
    color: "black"
  }
];

export { cars };