// import logo from './logo.svg';
import './App.css';
// import Garage from './Cars';
// import FavoriteColor from './FavoriteColor';

import React from "react";
// import ReactDOM from "react-dom/client";
import { Routes, Route, Router, BrowserRouter } from "react-router-dom";
import Layout from "./Layout";
import Home from "./Home";
import Blogs from "./Blogs";
import Contact from "./Contact";
import NoPage from "./NoPage";
import Routing from './Routing/Routing';
import HomePage from './Routing/HomePage';
import PostPage from './Routing/PostPage';
import Get from './Axios/Get';
import Post from './Axios/Post';
import Put from './Axios/Put';
import Delete from './Axios/Delete';
import Error from './Axios/Error';
import AsyncAwait from './Axios/AsyncAwait';



// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//         <Garage/>
//         <FavoriteColor/>
//         <FavoriteColor/>
//         <FavoriteColor/>
//       </header>
//     </div>
//   );
// }

function App1() {


  let colors = ["red", "yellow", "blue"];

  const addColor = (color) => {
    colors = [...colors, color];
    console.log(colors);
  };


  let cars = [
    {
      "name": "Tata Safari",
      "seats": 7,
    },
    {
      "name": "Maruti Baleno",
      "seats": 5,
    },
  ];

  const addCar = (car) => {
    console.log(car);
    cars = [...cars, car];
    console.log(cars);
  };

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home onAddNewColor={addColor} onAddNewCar={addCar} />} />
            <Route path="blogs" element={<Blogs />} />
            <Route path="contact" element={<Contact />} />
            <Route path="*" element={<NoPage />} />
          </Route>
        </Routes>
      </BrowserRouter>

    </>
  );
}

const App2 = () => {
  return (

    <Routing></Routing>

  );
};

const App = () => {
  return (
    <div className="App">

      <Get/>
      <br/>
      <hr/>
      <br/>
      <Post/>
      <br/>
      <hr/>
      <br/>
      <Put/>
      <br/>
      <hr/>
      <br/>
      <Delete/>
      <br/>
      <hr/>
      <br/>
      <Error/>
      <br/>
      <hr/>
      <br/>
      <AsyncAwait/>
      <br/>
      <hr/>
      <br/>
      
    </div>


  );
};

export default App;
