import { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { faEnvelope } from '@fortawesome/free-regular-svg-icons'
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import Button from 'react-bootstrap/Button';
import { Stack,Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const Home = (props) => {

  const [color, setColor] = useState("");

  const onAdd = () => {
    props.onAddNewColor(color);
    setColor("");
  };


  const [name, setName] = useState("");

  const [seats, setSeats] = useState(0);

  const addNewCar = () => {

    const c = {
      "name": name,
      "seats": seats
    };

    props.onAddNewCar(c);

    setName("");
    setSeats(0);

  };



  return <>
    <h1>Home</h1>


    <h3>Add Color</h3>
    <input type="text" value={color} onChange={(e) => setColor(e.target.value)} />
    <input type="button" onClick={onAdd} value="Add new color" />

    <h3>Add Car</h3>
    Car Name: <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
    <br />
    Car Seats: <input type="number" value={seats} onChange={(e) => setSeats(e.target.value)} />
    <br />
    <input type="button" onClick={addNewCar} value="Add New Car" />


    <br/>
    <br/>
    <FontAwesomeIcon icon={faEnvelope} />

    <br/>
    <br/>

    <Stack direction="horizontal" gap={2}>
      <Button as="a" variant="primary">
        Button as link
      </Button>
      <Button as="a" variant="success">
        Button as link
      </Button>
    </Stack>

    {/* <FontAwesomeIcon icon={solid('user-secret')} />
    <FontAwesomeIcon icon={regular('coffee')} />
    <FontAwesomeIcon icon={solid('user-secret')} />
    <FontAwesomeIcon icon={regular('coffee')} />
    <FontAwesomeIcon icon={icon({ name: 'coffee', style: 'solid' })} /> */}

  </>;


};

export default Home;