import {cars} from './data.js';
import { useState } from "react";

// function Car(props) {
//   return <li>I am a { props.brand }</li>;
// }

function Car(props) {
  const [car, setCar] = useState(props.data);

  const updateColor = () => {
    setCar(previousState => {
      return { ...previousState, color: "blue" }
    });
  }

  return (
    <li key={car.id}>
      <h1>My {car.brand}</h1>
      <p>
        It is a {car.color} {car.model} from {car.year}.
      </p>
      <button
        type="button"
        onClick={updateColor}
      >Blue</button>
    </li>
  )
}

function Garage() {
  const cars1 = cars;
  return (
    <>
      <ul key={1111}>
        {cars1.map((car) => <Car key={car.id} data={car} />)}
      </ul>


    </>
  );
}
export default Garage;