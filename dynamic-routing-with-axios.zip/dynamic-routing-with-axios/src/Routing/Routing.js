import React from "react";
import { Routes, Route, Router, BrowserRouter } from "react-router-dom";

import HomePage from "./HomePage";
import PostPage from "./PostPage";

const Routing = () => {
  return (

    <BrowserRouter>
      <Routes>
        {/* <Route path="/" element={<Layout />}> */}
          <Route index element={<HomePage></HomePage>} />
          <Route path="/post/:id" element={<PostPage></PostPage>} />
        {/* </Route> */}
      </Routes>
    </BrowserRouter>

);
};

export default Routing;