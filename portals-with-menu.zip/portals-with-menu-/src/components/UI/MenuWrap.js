import Menu from "../Users/Menu";
import React from 'react';
import ReactDOM from 'react-dom';

// import Card from './Card';
// import Button from './Button';
// import classes from './ErrorModal.module.css';


const MenuWrap = (props) => {
    console.log("Call menuwrap");
    console.log(props);
    return (
      <React.Fragment>
        {ReactDOM.createPortal(
          <Menu display={props.display} onClick={props.onClick}></Menu>,
          document.getElementById('menu-root')
        )}
      </React.Fragment>
    );
  };
  
  export default MenuWrap;
  