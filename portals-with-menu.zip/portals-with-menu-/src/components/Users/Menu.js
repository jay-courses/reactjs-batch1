import "./menu.css";
// import Button from '../UI/Button';

function Menu(props) {
    return <>
        <div className="menu-btn" onClick={props.onClick}>Menu</div>
        <div className={"menu " + props.display + " "}>
            <div className="sidemenu">
                <ul>
                    <li>
                        Home
                    </li>
                    <li>
                        About
                    </li>
                    <li>
                        Contact
                    </li>
                </ul>
            </div>
        </div>
    </>
}

export default Menu;