import React, { useState, Fragment } from 'react';
import MenuWrap from './components/UI/MenuWrap';

import AddUser from './components/Users/AddUser';
import Menu from './components/Users/Menu';
import UsersList from './components/Users/UsersList';

function App() {
  const [usersList, setUsersList] = useState([]);
  const [showMenu, setShowMenu] = useState("hide");

  const addUserHandler = (uName, uAge) => {
    setUsersList((prevUsersList) => {
      return [
        ...prevUsersList,
        { name: uName, age: uAge, id: Math.random().toString() },
      ];
    });
  };

  const toggleMenu = () => {
    if(showMenu == "hide"){
      setShowMenu("show");
    } else {
      setShowMenu("hide");
    }
  };

  return (
    <>
      <MenuWrap display={showMenu} onClick={toggleMenu}></MenuWrap>
      {/* <Menu display={showMenu} onClick={toggleMenu}></Menu> */}
      <AddUser onAddUser={addUserHandler} />
      <UsersList users={usersList} />
    </>
  );
}

export default App;
