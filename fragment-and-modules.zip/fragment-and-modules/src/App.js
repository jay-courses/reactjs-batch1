// import React from 'react';
import './App.css';
import Button from './Button/Button';
import React, { Fragment } from 'react';

function App() {

  const clickButton = () => {
    alert('Button clicked');
  }

  return (
    <>
    {/* <Fragment> */}
    {/* <React.Fragment> */}
    <div className="App"> 
      <header className="App-header">
      <Button type="submit" onClick={clickButton}>CSS Modules Example Button</Button>
      </header>
    </div>
    {/* </React.Fragment> */}
    {/* </Fragment> */}
    </>
  );
}

export default App;
