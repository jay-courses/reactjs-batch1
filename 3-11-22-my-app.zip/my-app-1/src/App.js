import image from './logo.svg';
import './App.css';
import Button from './Button/Button';
import Userbox from './Userbox/Userbox';
import Football from './Football';
import Garage from './Cars';
import UsersList from './UsersList';
import MyForm from './Form';
import FavoriteColor from './StateEx';
import CarEx from './CarEx';
import {car1, car2, car3, carsObj} from './data.js';


import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Blogs from "./pages/Blogs";
import Contact from "./pages/Contact";
import NoPage from "./pages/NoPage";

import Access from "./pages/Access";
import Signin from "./pages/Signin";
import Signup from "./pages/Signup";

import Fruit from "./Fruit.js";
import Color from './Color';
import {Timer, Counter, Fetchdata } from './Timer';



// function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path="/layout/" element={<Layout />}>
//           <Route index element={<Home myclass="redtitle" />} />
//           <Route path="blogs" element={<Blogs myclass="bluetitle" />} />
//           <Route path="contact" element={<Contact />} />
//           <Route path="*" element={<NoPage />} />
//         </Route>

//         <Route path="/access/" element={<Access />}>
//           <Route index element={<Signin />} />
//           <Route path="signup" element={<Signup />} />
//           <Route path="*" element={<NoPage />} />
//         </Route>

//       </Routes>
//     </BrowserRouter>
//   );
// }


// function App(props) {

//   let a = 5;
//   let b = 10;

//   console.log(props);

//   return (
//     <div className="App">
//       <header className="App-header">
//         {/* <img src={image} className="App-logo" alt="logo" /> */}
//         {/* <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a> */}
// {/* 
//         <p>{a*b}</p>
//         <h4>{props.name}</h4>
//         <h4>{props.age}</h4>
//         <Button name="Click"></Button>
//         <Button name="Submit"/> */}

//         {/* <Userbox img="1.jpg" name="Vivek"/>
//         <Userbox img="2.jpg" name="Utkarsh"/>
//         <Userbox img="3.jpg" name="Saqlain"/> */}
//         {/* <Football/>
//         <Garage/> */}
        
//         {/* <UsersList/>
//         <MyForm/>
//         <br/><br/> <br/><br/> <br/><br/>
//         <FavoriteColor/> */}


//         <div>
//           {carsObj.map((car) => <CarEx key={car.model} data={car} /> )}
//         </div>

//         {/* <CarEx data={car1}/>
//         <CarEx data={car2}/>
//         <CarEx data={car3}/> */}



//       </header>
//     </div>
//   );
// }



// function App(props) {

//   let a = 5;
//   let b = 10;

//   console.log(props);

//   // const fruit = {
//   //   name: "mango",
//   //   season: "summer"
//   // }

//   // const myFunction = (variable) => {
//   //   alert(variable);
//   //   // alert(fruit.name + " " + fruit.season);
//   // };

//   const myFunction = (obj) => {
//     // alert(variable);
//     alert(obj.name + " " + obj.season);
//   };

  

//   return (
//     <div className="App">
//       <header className="App-header">
//         <Fruit data={fruit} func={myFunction}/>
//       </header>
//     </div>
//   );
// }

function App(props) {


  let colors = ["Red", "Green", "Blue"];

  const addColor = (color) => {
    colors = [...colors, color];
    console.log(colors);
  };

  return (
    <div className="App">
      <header className="App-header">
        <Color onAddColor={addColor} />
        <Timer/>
        <Counter/>
        <Fetchdata/>
      </header>
    </div>
  );
}

export default App;
