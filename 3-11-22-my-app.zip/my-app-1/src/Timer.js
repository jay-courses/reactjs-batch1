import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";

function Timer() {
    const [count, setCount] = useState(0);

    let a = 10;

    useEffect(() => {
        console.log(count);
        setTimeout(() => {
            setCount((count) => count + 1);
        }, 1000);
    },[]);

    return <h1>I have rendered {count} times! {a}</h1>;
}


function Counter() {
    const [count, setCount] = useState(0);
    const [calculation, setCalculation] = useState(0);
  
    useEffect(() => {
        console.log("Re-render this component");
      setCalculation(() => count * 2);
    }, [count]); // <- add the count variable here
  
    return (
      <>
        <p>Count: {count}</p>
        <button onClick={() => setCount((c) => c + 1)}>+</button>
        <p>Calculation: {calculation}</p>
      </>
    );
  }



  
const Fetchdata = () => {
    const [data, setData] = useState(null);
  
    useEffect(() => {
        console.log(data);
      fetch("https://jsonplaceholder.typicode.com/todos")
        .then((res) => res.json())
        .then((data) => setData(data));
   },[]);
  
    return (
      <>
        {data &&
          data.map((item) => {
            return <p key={item.id}>{item.title}</p>;
          })}
      </>
    );
  };



export  {Timer, Counter, Fetchdata};