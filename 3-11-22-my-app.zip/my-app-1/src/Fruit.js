import { useState } from "react";

function Fruit(props) {
    
    const [name, setName] = useState("");
    const [season, setSeason] = useState("");
        
    const sendData = () => {
      const newFruit = {
        "name": name,
        "season": season
      };

      console.log(newFruit);
      setName("");
      setSeason("");
      props.func(newFruit);
    };
    return (
      <>

        Name: <input value={name} onChange={(e) => setName(e.target.value)} />
        Season: <input value={season} onChange={(e) => setSeason(e.target.value)} />
        <input type="button" onClick={sendData} value="Send Data"/>

      </>
    )
  }
  export default Fruit;