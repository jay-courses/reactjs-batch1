import { Outlet, Link } from "react-router-dom";

const Access = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="/access/">Sign in</Link>
          </li>
          <li>
            <Link to="/access/signup">Signup</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Access;