import './Image.css';

function Image(props){
    return <img src={props.filename} />;
}

export default Image;