import './Name.css';

function Name(props){
    return <h4 className='name'>{props.name}</h4>;
}

export default Name;