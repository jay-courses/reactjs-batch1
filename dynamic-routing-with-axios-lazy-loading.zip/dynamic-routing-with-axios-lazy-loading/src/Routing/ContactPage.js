// @src/pages/Home.jsx

// import React from "react";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import { Link } from "react-router-dom";

const ContactPage = () => {
  // const [posts, setPosts] = useState([]);

  return (
    <>
    <h2>Contact page</h2>
    <p>This is a contact page. Some content goes here.</p>
    </>
  );
};

export default ContactPage;