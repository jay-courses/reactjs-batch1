// @src/pages/Home.jsx

// import React from "react";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import { Link } from "react-router-dom";

const AboutPage = () => {
  // const [posts, setPosts] = useState([]);

  return (
    <>
    <h2>About page</h2>
    <p>This is a about page. Some content goes here.</p>
    </>
  );
};

export default AboutPage;