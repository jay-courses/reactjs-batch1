import React, { Suspense } from "react";
import { Routes, Route, Router, BrowserRouter } from "react-router-dom";

import HomePage from "./HomePage";
import PostPage from "./PostPage";
import ContactPage from "./ContactPage";
import AboutPage from "./AboutPage";
import Layout from "./Layout";
// import NoPage from "./NoPage";

const NoPage = React.lazy(() => import('./NoPage'));

const Routing = () => {
  return (
    <>
    <Suspense fallback={<p>Loading...</p>}>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage></HomePage>} />
          <Route path="/post/:id" element={<PostPage></PostPage>} />
          <Route path="/contact" element={<ContactPage></ContactPage>} />
          <Route path="/about" element={<AboutPage></AboutPage>} />
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
    </Suspense>
    </>
);
};

export default Routing;