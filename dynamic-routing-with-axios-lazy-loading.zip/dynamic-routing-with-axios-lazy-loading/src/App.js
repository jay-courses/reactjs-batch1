// import logo from './logo.svg';
import './App.css';
import React from "react";
import Routing from './Routing/Routing';


const App = () => {
  return (

    <Routing></Routing>

  );
};

export default App;
